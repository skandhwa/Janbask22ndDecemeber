package TestNG;

import org.testng.annotations.Test;

public class TestNGPriority {
	
	@Test(priority=0)
	public void test()
	{
		System.out.println("Hello i am 0");//5
		
	}
	
	@Test(priority=4)
	public void test1()
	{
		System.out.println("Hello i am 4");//6
		
	}
	
	@Test(priority=-2)
	public void test2()
	{
		System.out.println("Hello i am -2");//1
		
	}
	
	@Test
	public void zyx()
	{
		System.out.println("Hello i am default1");//4
		
	}
	
	@Test
	public void def()
	{
		System.out.println("Hello i am default 2");//3
		
	}
	
	@Test(priority=-1)
	public void test4()
	{
		System.out.println("Hello i am 4");//2
		
	}
	
	
	

}
