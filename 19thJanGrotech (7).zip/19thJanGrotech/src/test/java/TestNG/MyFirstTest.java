package TestNG;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class MyFirstTest {
	
	@BeforeMethod
	public void Test1()
	{
		System.out.println("Hello");//2
	}
	
	@AfterSuite
	public void Test2()
	{
		System.out.println("How r u");//5
	}
	
	@Test
	public void Test3()
	{
		System.out.println("I am TestMethod");//3
	}
	
	
	@BeforeSuite
	public void Test4()
	{
		System.out.println("I am BeforeSuite");///1
	}
	
	
	@AfterMethod
	public void Test5()
	{
		System.out.println("I am AfterMethod");//4
	}
	
	
	

}
