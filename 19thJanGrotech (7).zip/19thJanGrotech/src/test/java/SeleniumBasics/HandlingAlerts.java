package SeleniumBasics;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlerts {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		//SIMPLE ALERT 
		
//		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
		
		//CONFIRMATION ALERT 
		
//		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().dismiss();
//	String Text=	driver.findElement(By.xpath("//p[@id='demo']")).getText();
//		System.out.println(Text);
		
		//Prompt Alert
		
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Thread.sleep(3000);
		Alert alert=driver.switchTo().alert();
		Thread.sleep(5000);
		alert.sendKeys("Saurabh");
		Thread.sleep(3000);
		//alert.sendKeys("test@1234");
		alert.accept();
String Text=		driver.findElement(By.xpath("//p[@id='demo1']")).getText();
		
		System.out.println(Text);
		
		
		
		
		

	}

}
