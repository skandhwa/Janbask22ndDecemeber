package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementExample7 {

	public static void main(String[] args) {
    WebDriver driver=new ChromeDriver();
	driver.get("https://grotechminds.com/registration/");
	WebElement ele=	driver.findElement(By.xpath("//input[@id='fname']"));
	Point p=ele.getLocation();
	System.out.println(p.getX());
	System.out.println(p.getY());

	}

}
