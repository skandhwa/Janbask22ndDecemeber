package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleDynamicWebTablePart2 {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("C:\\Users\\saura\\Downloads\\WebTable.html");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//td[contains(text(),'Tom')]//preceding-sibling::td//input[@type='checkbox']")).click();

	}

}
