package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AssertingLoginButton {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@name='btnLogin']"));
     if(ele.isDisplayed()==true)
     {
    	 System.out.println("Test case passed");
     }
     else
     {
    	 System.out.println("Test case failed");
     }
     
     JavascriptExecutor js=(JavascriptExecutor)driver;
     js.executeScript("window.scrollBy(0,1000)","");
     
     driver.findElement(By.xpath("//a[text()='Log out']")).click();
     
     Thread.sleep(3000);
     
   String CurrentURL=  driver.getCurrentUrl();
   
   if(CurrentURL.contains("index"))
   {
	   System.out.println("Test case passed");
   }
   else
   {
  	 System.out.println("Test case failed");
   }
	
	
	}

}
