package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class E2EScenario {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.manage().window().maximize();
		//mngr551332
		//jEsyvUv
		
		
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr551332");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("jEsyvUv");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
		Thread.sleep(3000);
	String CurrentURL=	driver.getCurrentUrl();
	if(CurrentURL.contains("guru99"))
	{
		System.out.println("Test case passed");
	}
		
	else
	{
		System.out.println("Test Case Failed");
	}
		
	Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys("asdsadm332");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("asdasdasjEsyvUv");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();	
		Thread.sleep(3000);
		
		String CurrentURL1=	driver.getCurrentUrl();
		if(CurrentURL1.contains("guru99"))
		{
			System.out.println("Test case passed");
		}
			
		else
		{
			System.out.println("Test Case Failed");
		}
		
		
	}

}
