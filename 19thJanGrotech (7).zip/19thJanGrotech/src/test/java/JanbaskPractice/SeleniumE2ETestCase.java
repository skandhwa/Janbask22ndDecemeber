package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumE2ETestCase {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.wikipedia.org/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='searchInput']")).sendKeys("Selenium(software)");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//span[text()='Create account'])[1]")).click();
		Thread.sleep(3000);
	String Current_URL1=	driver.getCurrentUrl();
	Thread.sleep(3000);
	System.out.println(Current_URL1);
	driver.navigate().back();
	Thread.sleep(3000);
	driver.findElement(By.xpath("//a[@title='Selenium (software)']")).click();
	Thread.sleep(3000);
	String Current_URL2=	driver.getCurrentUrl();	driver.getCurrentUrl();
	Thread.sleep(3000);
	if(Current_URL1.contains("wiki") && Current_URL2.contains("wiki") )
	{
		System.out.println("Test case Passed");
	}
	else
	{
		System.out.println("Test case Failed");
	}
	
	

	}

}
