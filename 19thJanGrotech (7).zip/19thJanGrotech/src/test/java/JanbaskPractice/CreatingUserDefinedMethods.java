package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CreatingUserDefinedMethods {
	
	
	WebDriver driver=new FirefoxDriver();
	
	public void login(String username,String password) throws InterruptedException
	{
		
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(username);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
		Thread.sleep(3000);
		WebElement ele=	driver.findElement(By.xpath("//input[@name='btnLogin']"));
		ele.click();
	}
	
	public void closeBrowser()
	{
		driver.close();
	}
	
	public void handleAlert()
	{
		driver.switchTo().alert().accept();
	}
	
	
	public static void main(String[] args) throws InterruptedException {
		
		CreatingUserDefinedMethods obj=new CreatingUserDefinedMethods();
		CreatingUserDefinedMethods obj1=new CreatingUserDefinedMethods();
		CreatingUserDefinedMethods obj2=new CreatingUserDefinedMethods();
		CreatingUserDefinedMethods obj3=new CreatingUserDefinedMethods();
		obj.login("mngr551332", "jEsyvUv");
		Thread.sleep(3000);
		obj.closeBrowser();
		obj1.login("mngr552121", "zYhugYs");
		Thread.sleep(3000);
		obj1.closeBrowser();
		
		obj2.login("mngr553432", "zYhuerd");
		Thread.sleep(3000);
		obj2.handleAlert();
		obj2.closeBrowser();
		
		
		obj3.login("mngr553499", "aYhuerd");
		Thread.sleep(3000);
		obj3.handleAlert();
		obj3.closeBrowser();
		
		
		

	}

}
