package JanbaskPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MySecondTest {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.google.com");
		driver.manage().window().maximize();
//	String title=	driver.getTitle();
//	System.out.println(title);
//	
//	String CurrentURL=driver.getCurrentUrl();
//	System.out.println(CurrentURL);
	
	String PageSource=	driver.getPageSource();
	System.out.println(PageSource);
	
	Thread.sleep(5000);
	driver.close();
		
		
		

	}

}
