package JanbaskPractice;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingFramesEx2 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Frames.html");
	List<WebElement> li=	driver.findElements(By.tagName("iframe"));
	int x=li.size();
	System.out.println("The total size of list is "+x);
	driver.findElement(By.xpath("//a[@href='#Multiple']")).click();

	}

}
