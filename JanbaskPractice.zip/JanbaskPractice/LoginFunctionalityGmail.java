package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginFunctionalityGmail {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.manage().window().maximize();
		
		WebElement UserName=driver.findElement(By.xpath("//input[@name='uid']"));
		
		if(UserName.isDisplayed())
		{
		
		
		driver.findElement(By.xpath("//input[@name='uid']")).clear();
		Thread.sleep(3000);
		//driver.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr551332");
		//Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("jEsyvUv");
		Thread.sleep(3000);
		
		}
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
		
		driver.switchTo().alert().accept();
		
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@name='uid']")).clear();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr551332");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("jEsyvUv");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
		
	String Title=	driver.getTitle();
	System.out.println(Title);
	
	if(Title.contains("HomePage"))
	{
		System.out.println("Test case passed");
	}
	else
	{
		System.out.println("Test case failed");
	}
		
	
	 Thread.sleep(3000);
     
     JavascriptExecutor js=(JavascriptExecutor)driver;
     js.executeScript("window.scrollBy(0,1000)","");
     
     driver.findElement(By.xpath("//a[text()='Log out']")).click();
     
     Thread.sleep(3000);
     
     driver.switchTo().alert().accept();
     Thread.sleep(3000);
     
   String CurrentURL=  driver.getCurrentUrl();
   
   if(CurrentURL.contains("index"))
   {
	   System.out.println("Test case passed");
   }
   else
   {
  	 System.out.println("Test case failed");
   }
	
	
	
		

	}

}
