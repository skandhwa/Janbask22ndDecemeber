package SeleniumBasics;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TakingScreenShotExample {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com");
		
//		File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//		FileUtils.copyFile(f, new File("E:\\TestData\\Mytest.jpg"));
//		System.out.println("Screenshot captured");
		
		
		
		TakesScreenshot srcshot=(TakesScreenshot)driver;
		 File Srcfile= srcshot.getScreenshotAs(OutputType.FILE);
		 File DestPath=new File("E:\\TestData\\"+Math.random()+"\\Mytest2.jpg");
		 FileUtils.copyFile(Srcfile,DestPath);
		 System.out.println("Screenshot captured");

	}

}
