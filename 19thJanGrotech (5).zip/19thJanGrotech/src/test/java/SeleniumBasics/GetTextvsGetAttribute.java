package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetTextvsGetAttribute {

	public static void main(String[] args) {
		///   //label[text()='First name:']
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://grotechminds.com/registration/");
		driver.manage().window().maximize();
WebElement ele=		driver.findElement(By.xpath("//label[text()='First name:']"));
String value=ele.getText();
System.out.println(value);


	}

}
