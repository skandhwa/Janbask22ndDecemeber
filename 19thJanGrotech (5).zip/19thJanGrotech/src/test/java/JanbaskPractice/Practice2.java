package JanbaskPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Practice2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		Thread.sleep(5000);
	WebElement ele=	driver.findElement(By.xpath("//div[@id='msdd']"));
	Thread.sleep(5000);
	Select oselect=new Select(ele);
	if(oselect.isMultiple())
	{
		oselect.selectByIndex(1);
		oselect.selectByIndex(2);
	}
	
	
	

	}

}
