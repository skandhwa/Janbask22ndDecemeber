package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands5 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://grotechminds.com/registration/");
		driver.manage().window().maximize();
		
	WebElement ele=	driver.findElement(By.xpath("//input[@id='Agree']"));
	Thread.sleep(5000);
	boolean flag=ele.isSelected();
	System.out.println(flag);
	
	if(flag==false)
	{
		ele.click();
		
	}
		
	Thread.sleep(8000);
	
	driver.findElement(By.xpath("//input[@value='Submit' and @type='submit' and @fdprocessedid='3e89ir'] ")).submit();
	
	driver.close();	
		

	}
	
	
	

}
