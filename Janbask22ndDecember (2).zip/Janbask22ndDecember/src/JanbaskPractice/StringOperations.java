package JanbaskPractice;

public class StringOperations {

	public static void main(String[] args) {
		
		String str="Selenium";
		String str2="UFT";
		
		System.out.println(str+" "+str2);
		
		System.out.println("1"+"4+5"+str+str2);
		
		
		
		

	}

}
