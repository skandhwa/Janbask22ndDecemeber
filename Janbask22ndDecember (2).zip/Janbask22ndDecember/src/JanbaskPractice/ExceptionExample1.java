package JanbaskPractice;

public class ExceptionExample1 {

	public static void main(String[] args) {
		
		
//		try
//		{
//		
//		int t=100;
//		int x=t/0;
//		System.out.println(x);
//		
//		}
//		
//		catch(Exception e)
//		{
//			System.out.println("caught with "+e);
//		}
		
		
		
		try
		{
		
		String name=null;
		int z=name.length();
		System.out.println(z);
		
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		
		

	}

}
