package JanbaskPractice;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreatingAFile {

	public static void main(String[] args) throws IOException {
		
		
//		File obj=new File("D:\\File Demo\\UserDemo.txt");
//	boolean flag=	obj.createNewFile();
//	System.out.println(flag);
		
		FileWriter fw=new FileWriter("D:\\File Demo\\abc.txt");
	    fw.write("This file is created for User demo purpose");
	    fw.close();
		
		

	}

}
