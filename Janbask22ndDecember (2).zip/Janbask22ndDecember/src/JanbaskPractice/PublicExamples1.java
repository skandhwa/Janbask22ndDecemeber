package JanbaskPractice;

public class PublicExamples1 {
	
	public void display()
	{
		System.out.println("Hello");
	}
	
	

	public static void main(String[] args) {
		
		
		PublicExamples1 obj=new PublicExamples1();
		obj.display();

	}

}
