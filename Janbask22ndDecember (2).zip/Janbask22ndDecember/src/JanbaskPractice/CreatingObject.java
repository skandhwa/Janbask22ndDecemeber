package JanbaskPractice;

public class CreatingObject {
	

	
	
	void addition()
	{
		int a=20,b=30,c=40;
		int sum=a+b+c;
		System.out.println(sum);
		
		
	}
	
	
	
	

	public static void main(String[] args) {
		
		
		CreatingObject obj=new CreatingObject();
		obj.addition();
		
		
	}

}
