package JanbaskPractice;

import java.util.*;


public class MyFirstJavaProgram {

	public static void main(String[] args) {
		
		System.out.println("Hello How are you");
		
		
		

	}

}
