package JanbaskPractice;

public class WhileLoopExample {

	public static void main(String[] args) {
		
		int i=10;
		
		while(i<5)//1<5//2<5//3<5//4<5//5<5
		{
			System.out.println(i);//1//2//3//4//
			i++;//1++//2++//3++//4++
		}
		

	}

}
