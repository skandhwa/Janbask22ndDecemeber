package JanbaskPractice;

import java.util.Scanner;

public class TakingInputAsString {

	public static void main(String[] args) {
		
		System.out.println("Enter your Name");
		
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		
	int x=	name.length();
	
	System.out.println("The length of String is "+x);
	
	
	System.out.println("Enter Your Mobile Number");
	long y=sc.nextLong();
	
	System.out.println("The Mobile Number Entered by you is "+y);
	
		
	System.out.println("Enter Your Area of house");
	float z=sc.nextFloat();
	
	System.out.println("The Area Entered by you is "+z);
	
	System.out.println("Enter Either True or False value");
	boolean flag=sc.nextBoolean();
	
	System.out.println("The Flag entered by you is "+flag);	
		

	}

}
