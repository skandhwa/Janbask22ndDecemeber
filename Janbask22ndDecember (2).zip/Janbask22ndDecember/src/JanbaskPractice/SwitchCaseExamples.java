package JanbaskPractice;

public class SwitchCaseExamples {

	public static void main(String[] args) {
		
		char grade='D';
		switch(grade)
		
		{
		case 'A':
		System.out.println("Excellent");
		break;
		
		case 'B':
			System.out.println("Very Good");
			break;
			
		case 'C':
			System.out.println("Good");
			break;
			
		case 'D':
			System.out.println("Satisfactory");
			break;
			
		default:
			System.out.println("Not found");
		
		
		}
		
		

	}

}
