package JanbaskPractice2;

public class DefaultExample4 {

	public static void main(String[] args) {
		
		DefaultExample3 obj=new DefaultExample3();
		
		
		

	}

}
