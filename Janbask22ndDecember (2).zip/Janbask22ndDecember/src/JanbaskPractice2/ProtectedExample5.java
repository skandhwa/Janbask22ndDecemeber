package JanbaskPractice2;

import JanbaskPractice.ProtectedExample1;
import JanbaskPractice.ProtectedExample2;
import JanbaskPractice.ProtectedExample3;

public class ProtectedExample5 extends ProtectedExample1 {

	public static void main(String[] args) {
	
		ProtectedExample5 obj2=new ProtectedExample5();
		obj2.display();
		

	}

}
