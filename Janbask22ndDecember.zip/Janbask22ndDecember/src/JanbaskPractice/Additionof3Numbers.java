package JanbaskPractice;

public class Additionof3Numbers {

	public static void main(String[] args) {
		
		
		int x=10,y=20,z=30;
		//float y=13.5f;
		
		
		
		int sum=x+y+z;
		System.out.println(sum);
		
		

	}

}
