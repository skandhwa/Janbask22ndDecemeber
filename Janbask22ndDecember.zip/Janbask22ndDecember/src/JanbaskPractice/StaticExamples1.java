package JanbaskPractice;


class A
{
	
	final int x=100;
	
	 void display()
	{
		System.out.println("Hello");
		x=200;
	}
}



public class StaticExamples1 {

	public static void main(String[] args) {
		
		A.display();
		
		
		
		

	}

}
