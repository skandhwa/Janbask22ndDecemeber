package JanbaskPractice;


class DefaultExample3
{
	void display()
	{
		System.out.println("Hello");
	}
}





public class DefaultExample {

	public static void main(String[] args) {
		
		
		
	

	}

}
