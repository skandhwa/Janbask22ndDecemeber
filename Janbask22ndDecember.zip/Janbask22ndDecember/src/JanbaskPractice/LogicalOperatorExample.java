package JanbaskPractice;

public class LogicalOperatorExample {

	public static void main(String[] args) {
		
		
		

	}

}
