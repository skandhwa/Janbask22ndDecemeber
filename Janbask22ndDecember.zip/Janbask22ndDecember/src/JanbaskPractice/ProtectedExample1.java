package JanbaskPractice;

 class ProtectedExample2
{
	protected void display()
	{
		System.out.println("Hello");
	}
}


public class ProtectedExample1 {

	public static void main(String[] args) {
		
		ProtectedExample2 obj=new ProtectedExample2();
		obj.display();
		
		

	}

}
