package MyRestProject;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;


public class MyRestCode {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in/api/users";
	String Response=	given().log().all().queryParam("page","2").headers("Connection","keep-alive").
		when().get().then().extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
String ID=	js.getString("data[0].id");

System.out.println("The Id value is "+ID);

String FirstName="Michael123";

String FName=js.getString("data[0].first_name");
System.out.println(FName);

Assert.assertEquals(FirstName, FName);



String Lname=js.getString("data[3].last_name");
System.out.println(Lname);
		
		
		
		
		
		

	}

}
