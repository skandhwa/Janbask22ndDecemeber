package MyRestProject;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


public class MySecondTest {

	public static void main(String[] args) {
		
		
         RestAssured.baseURI="https://reqres.in/api/users";
         
    String Response=     given().log().all().body("\r\n"
         		+ "{\r\n"
         		+ "    \"name\": \"morpheus\",\r\n"
         		+ "    \"job\": \"leader\"\r\n"
         		+ "}")
         
         .when().post().
         
         then().extract().response().asString();
    
    System.out.println(Response);
         
          JsonPath js=new JsonPath(Response);
          
       String ID=   js.get("id");
       
       System.out.println(ID);
       
  
         
         
         
         
		
	
	
	
	

	}

}
