package MyRestProject;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;

public class MyFirstTest {

	public static void main(String[] args) {
		
		int ID=21;
		String Act_Firstname="Janet";
		
		RestAssured.baseURI="https://reqres.in/api/users/2";
	String Response= given().log().all().
			when().get().then().extract().response().asString();
	 System.out.println(Response);
	 
	 
	 
	 JsonPath js=new JsonPath(Response);
	 
int value=	 js.get("data.id");
System.out.println(value);

String FirstName=js.get("data.first_name");
System.out.println(FirstName);

Assert.assertEquals(Act_Firstname,FirstName);

Assert.assertEquals(ID, value);

System.out.println("Test Case Passed");
	 
	 
		
		
		

	}

}
