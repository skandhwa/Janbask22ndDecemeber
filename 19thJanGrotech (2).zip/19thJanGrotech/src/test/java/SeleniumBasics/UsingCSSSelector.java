package SeleniumBasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UsingCSSSelector {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://grotechminds.com/registration/");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='Male']")).click();
		
		
////	WebElement ele=	driver.findElement(By.cssSelector("input[id='fname']"));
////		
////	ele.sendKeys("Saurabh");
//	
//		
		driver.findElement(By.cssSelector("input[id='fname']")).sendKeys("Saurabh");
		Thread.sleep(3000);
		
		driver.findElement(By.cssSelector("input[id='fname']")).clear();

	//	driver.get("https://www.google.com");
		//driver.findElement(By.xpath("//textarea[@class='gLFyf34543']")).sendKeys("Selenium");
		
		
//	List<WebElement> li=	driver.findElements(By.tagName("rtertretretr"));
//	int x=li.size();
//	System.out.println("Total number of web links are "+x);
	
		
		
		
	}

}
