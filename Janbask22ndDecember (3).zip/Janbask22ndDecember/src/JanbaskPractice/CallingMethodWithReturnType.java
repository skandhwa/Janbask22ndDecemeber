package JanbaskPractice;


class CRT
{
	
	static int add(int a,int b)
	{
		return a+b;
		
	}
	
	int sub(int c,int d)
	{
		return c-d;
	}
	
}
public class CallingMethodWithReturnType {

	public static void main(String[] args) {
		
		
	System.out.println(CRT.add(30, 90));	
		
		
//	System.out.println((CRT.obj.add(25, 90));
//	
//	System.out.println(obj.sub(45, 15));
//		
		
		

	}

}
