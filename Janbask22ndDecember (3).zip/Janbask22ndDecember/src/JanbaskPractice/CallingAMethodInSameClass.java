package JanbaskPractice;

public class CallingAMethodInSameClass {
	
	
	void test()
	{
		System.out.println("Hello");
	}
	
	

	public static void main(String[] args) {
		
		CallingAMethodInSameClass obj=new CallingAMethodInSameClass();
		obj.test();
		
		
	}

}
