package JanbaskPractice;


class Ext1
{
	static  int mul(int x,int y)
	{
		
		return x*y;
		
	}
}


public class MethodExamples7 {

	public static void main(String[] args) {
		
//		Ext1 obj=new Ext1();
		
		
	System.out.println(Ext1.mul(56, 12));	
		

	}

}
