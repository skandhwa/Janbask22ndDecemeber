package JanbaskPractice;

public class Numbermethodsexample {

	public static void main(String[] args) {
		
		int x=5;
		Integer a=x;
		//System.out.println(a.compareTo(5));
		
		System.out.println(a.equals(5));
		
		
		
		float y=45.56657f;
		System.out.println(Math.abs(y));
		
		
		int d=46;
		int e=56;
		
		System.out.println(Math.min(d, e));
		
		
		System.out.println(Math.random());
		
		
		
		char ch='a';
		
		//System.out.println(Character.isLetter(ch));
		
		System.out.println(Character.isAlphabetic(ch));
	}

}
