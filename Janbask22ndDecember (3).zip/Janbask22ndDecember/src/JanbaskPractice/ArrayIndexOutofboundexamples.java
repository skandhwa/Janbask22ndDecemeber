package JanbaskPractice;

public class ArrayIndexOutofboundexamples {

	public static void main(String[] args) {
		
		
		try
		{
		
		int []a= {12,34,56,78};
		
		System.out.println(a[6]);
		
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		int r=10;
		int b=20;
		int c=r+b;
		System.out.println("The sum of two number is  "+c);
		

	}

}
