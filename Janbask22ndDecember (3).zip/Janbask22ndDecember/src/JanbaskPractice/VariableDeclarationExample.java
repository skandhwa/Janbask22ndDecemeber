package JanbaskPractice;

public class VariableDeclarationExample {
	
	static int x=20;
	
	void display()
	{
		int y=x+30;
		int m=20;
		
		
	}
	
	
	

	public static void main(String[] args) {
		
		
		
		
		

	}

}
