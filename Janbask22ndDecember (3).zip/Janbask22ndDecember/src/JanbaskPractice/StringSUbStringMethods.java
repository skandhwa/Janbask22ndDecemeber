package JanbaskPractice;

public class StringSUbStringMethods {

	public static void main(String[] args) {
		
		
		
		String str="Saurabh testing";
		
	boolean flag=	str.endsWith("g");
	
	System.out.println(flag);
		
	String str2=	str.substring(2,5);
	System.out.println(str2);
	
	int x=str.length();
	
	System.out.println("Length is  "+x);

	}

}
