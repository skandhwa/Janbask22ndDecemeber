package JanbaskPractice;

public class AssignmentOperatorExample {

	public static void main(String[] args) {
		
		int a=10;
		
	 a%=3;
	 
	 System.out.println(a);
		
		

	}

}
