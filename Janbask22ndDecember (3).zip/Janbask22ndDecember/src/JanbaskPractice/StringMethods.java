package JanbaskPractice;

public class StringMethods {

	public static void main(String[] args) {
	
//		String str1="Abcd";
//		String str2="accd";
//		
//		
//		System.out.println(str1.compareTo(str2));
		
		
		String str1="Java";
		String str2="java";
		
		System.out.println(str1.equalsIgnoreCase(str2));
		

	}

}
