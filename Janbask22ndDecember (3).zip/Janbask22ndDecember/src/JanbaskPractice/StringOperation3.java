package JanbaskPractice;

public class StringOperation3 {

	public static void main(String[] args) {
		
		String str="AB";//
		String str1="ab";//
		
		System.out.println(str1.compareTo(str));
		

	}

}
