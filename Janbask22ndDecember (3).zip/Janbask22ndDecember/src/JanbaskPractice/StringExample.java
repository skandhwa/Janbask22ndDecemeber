package JanbaskPractice;

public class StringExample {

	public static void main(String[] args) {
		
		
		String str="1234";
		String str1="Saurabh1234@#$*";
		
		String str2="Java";
		String []a= {"UFT","Selenium","Php","LoadRunner"};
		
		for(String x:a)
		{
			System.out.println(x);
		}
		
		
		for(int i=0;i<a.length;i++)
			
		{
			System.out.println(a[i]);
		}
		
		

	}

}
