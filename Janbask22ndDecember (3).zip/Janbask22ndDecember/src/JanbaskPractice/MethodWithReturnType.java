package JanbaskPractice;


class Ex2
{
	static int division(int a,int b)
	{
		return a/b;
	}
}




public class MethodWithReturnType {

	public static void main(String[] args) {
		
		
	System.out.println(Ex2.division(20, 4))	;
		

	}

}
