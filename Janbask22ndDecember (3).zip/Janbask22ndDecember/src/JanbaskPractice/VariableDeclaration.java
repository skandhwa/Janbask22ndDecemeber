package JanbaskPractice;

public class VariableDeclaration {

	public static void main(String[] args) {
		
		int x=100,y=20,z=30;
		int b=x;
		

	}

}
