package JanbaskPractice;

public class PublicExample3 {

	public static void main(String[] args) {
		
		
		PublicExamples1 obj=new PublicExamples1();
		obj.display();

	}

}
