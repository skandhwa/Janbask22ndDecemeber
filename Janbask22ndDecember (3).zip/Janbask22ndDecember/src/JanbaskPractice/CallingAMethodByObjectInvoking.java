package JanbaskPractice;

class RT

{
	static void display()
	{
		System.out.println("Hello How Are you");
	}
}


public class CallingAMethodByObjectInvoking {

	public static void main(String[] args) {
		
		RT.display();
		
		
		

	}

}
