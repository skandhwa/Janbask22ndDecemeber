package JanbaskPractice;

public class ArithmeticOperations {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		int d=b-a;
		System.out.println(d);
		int e=a*b;
		System.out.println(e);
		
		int m=22;
		int n=22/4;
		System.out.println(n);
		
		int v=--b;
		System.out.println(v);
		

	}

}
