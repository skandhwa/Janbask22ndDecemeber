package JanbaskPractice;

public class ArrayExamples3 {

	public static void main(String[] args) {
		
		int []a= {12,34,56,78,99};
		
		int []f=a;
		System.out.println("Copied values are");
		
		for(int x:f)
		{
			System.out.println(x);
		}
		
		
		System.out.println("*****************************************");
		
		System.out.println(a[2]);
		
		int []b=new int[3];
		
		b[0]=34;
		b[1]=56;
		b[2]=78;
		
		
		char[]ch= {'A','c','1','B'};
		String []str1= {"UFT","Selenium","Python"};
		
		System.out.println(str1[2]);
		
		boolean []flag= {false,true,false};
		
		
	}

}
