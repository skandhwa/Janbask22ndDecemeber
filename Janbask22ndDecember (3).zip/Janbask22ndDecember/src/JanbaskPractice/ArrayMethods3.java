package JanbaskPractice;

import java.util.Arrays;

public class ArrayMethods3 {

	public static void main(String[] args) {
		
		
		String []arr= {"UFT","Selenium","Java"};
		
	System.out.println(Arrays.asList(arr).contains("python"));	
		
		

	}

}
