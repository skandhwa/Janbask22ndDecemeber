package JanbaskPractice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadDataFromFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		File obj1=new File("D:\\File Demo\\abc2.txt");
		Scanner sc=new Scanner(obj1);
		
		while(sc.hasNextLine())
		{
			String data=sc.nextLine();
			System.out.println(data);
		}
		
		sc.close();
		
		boolean flag=obj1.delete();
		System.out.println("Is the file deleted  "+flag);
		

	}

}
