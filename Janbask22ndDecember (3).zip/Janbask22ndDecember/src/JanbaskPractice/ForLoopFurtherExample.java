package JanbaskPractice;

public class ForLoopFurtherExample {

	public static void main(String[] args) {
		
		int a=10;
		
		
		if(a>1 && a<10)///10>1,10<10
		{
			System.out.println("a is small number");
		}
		
		else if(a>=10 && a<100)///10>=10
		{
			System.out.println("a is medium number");
		}
		
		else if(a>=100 && a<1000)
		{
			System.out.println("a is large number");
		}
		

	}

}
