package JanbaskPractice;

class UD2
{
	public static float add(int x,int y)
	{
		return x+y;
	}
}




public class UserDefinedMethods2 {

	public static void main(String[] args) {
		
	System.out.println(UD2.add(34, 78));	
		

	}

}
