package JanbaskPractice;

public class JavaConditionChecking {

	public static void main(String[] args) {
		
		
		int a=130;
		int b=40;
		
		
		for(int i=0;i<10;i++)
		{
			
		}
		
		if(a>b)///130>40
		{
			System.out.println("Maximum is A");
		}
		
		else
		{
			System.out.println("Maximum is B");
		}

	}

}
