package JanbaskPractice;


class MT
{
	static int multiply(int a,int b,int c)
	{
		return a*b*c;
	}
	
}


public class MethodsThatReturnAvalue {

	public static void main(String[] args) {
		
	System.out.println(MT.multiply(34, 14, 12));	
		

	}

}
