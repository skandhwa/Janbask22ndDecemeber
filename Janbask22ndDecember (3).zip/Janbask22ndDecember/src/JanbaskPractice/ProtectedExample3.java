package JanbaskPractice;

public class ProtectedExample3 {

	public static void main(String[] args) {
		
		ProtectedExample2 obj=new ProtectedExample2();
		obj.display();
		
		

	}

}
