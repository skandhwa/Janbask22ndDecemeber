package JanbaskPractice;

import java.util.regex.*;

public class StringMethodsExample2 {

	public static void main(String[] args) {
 
		
		String str1="Java";
		String str2="Python";
		
	char ch=	str1.charAt(3);
	System.out.println(ch);
		
//		str1.concat(str2);
//	
//	System.out.println(str1);
		
		
		String str3=str1+str2;
		System.out.println(str3);
	
	
	

		

	}

}
