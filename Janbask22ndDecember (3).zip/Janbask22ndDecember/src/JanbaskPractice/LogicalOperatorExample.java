package JanbaskPractice;

public class LogicalOperatorExample {

	public static void main(String[] args) {
		
		
		int a=10;
		int b=20;
		int c=50;
		int d=40;
		
		
		if(a<b || a>c && d<b || c<b)///10<20 ,10>50,40<20
		{
			System.out.println("True");
		}
		else
		{
			System.out.println("false");
		}
		
		
		

	}

}
