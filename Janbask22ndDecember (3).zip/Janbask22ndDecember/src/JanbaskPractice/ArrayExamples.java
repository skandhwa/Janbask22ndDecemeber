package JanbaskPractice;

public class ArrayExamples {

	public static void main(String[] args) {
		
		
		int []a= {23,45,67,89,99,101};
		
		int x=a.length;
		
		System.out.println("Length of array is  "+x);
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		for(int y:a)
		{
			System.out.println(y);
		}
		
		
		
		//int []b=new int[] {46,99,12,34,89};

	}

}
