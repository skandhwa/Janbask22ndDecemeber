package JanbaskPractice;

public class ExceptionHandlingSecondexamples {

	public static void main(String[] args) {
		
		
		try
		{
		String s="abc";
		
		int a=Integer.parseInt(s);
		System.out.println(a);
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		int r=10;
		int b=20;
		int c=r+b;
		System.out.println("The sum of two number is  "+c);
		
		

	}

}
