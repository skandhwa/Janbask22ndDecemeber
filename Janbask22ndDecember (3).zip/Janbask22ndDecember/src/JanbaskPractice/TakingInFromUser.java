package JanbaskPractice;

import java.util.Scanner;

public class TakingInFromUser {

	public static void main(String[] args) {
		
		System.out.println("Enter the first number");
		
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		
        System.out.println("Enter the Second number");
		
		
		int num1=sc.nextInt();
		
		int sum=num1+num;
		
		System.out.println("The sum of two number is "+sum);
		
		
		
		
		
		

	}

}
