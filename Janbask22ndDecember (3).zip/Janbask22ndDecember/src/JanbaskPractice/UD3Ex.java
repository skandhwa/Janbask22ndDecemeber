package JanbaskPractice;

public class UD3Ex {

	public static void main(String[] args) {
		
		
		UD2 obj=new UD2();
		System.out.println(obj.add(45, 67));

	}

}
