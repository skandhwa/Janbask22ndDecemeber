package JanbaskPractice;

public class DoWhileLoopExamples {

	public static void main(String[] args) {
		
		int i=10;
		do
		{
			System.out.println(i);//1//2
			i++;//1++
		}
		
		while(i<5);//1<5
		
		
		

	}

}
