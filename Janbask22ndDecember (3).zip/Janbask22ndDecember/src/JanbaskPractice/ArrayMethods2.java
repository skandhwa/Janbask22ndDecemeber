package JanbaskPractice;

import java.util.Arrays;

public class ArrayMethods2 {

	public static void main(String[] args) {
		
		
		int []a= {12,34,56,78};
		int x=a.length;
		System.out.println(x);
		
		
		String []arr= {"UFT","Selenium","Java"};
	System.out.println(Arrays.toString(arr));	
		
		
	}

}
