package JanbaskPractice;

public class StringOperations2 {

	public static void main(String[] args) {
		
		String str="Java";
		String str2="java";
		String str3="Java";
		
//		if(str==str2)
//		{
//			System.out.println("true");
//		}
//		
//		else
//		{
//			System.out.println("false");
//		}
		
		if(str.equalsIgnoreCase(str2))
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		
		

	}

}
