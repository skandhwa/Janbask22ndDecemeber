package JanbaskPractice;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="    USA   ";
		
		System.out.println(str);
		
	String str2=	str.toLowerCase();
	
	String str3=str2.trim();
	
	System.out.println(str3);
	
	
		

	}

}
