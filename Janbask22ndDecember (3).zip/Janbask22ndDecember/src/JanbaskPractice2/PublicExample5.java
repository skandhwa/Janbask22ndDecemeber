package JanbaskPractice2;

import JanbaskPractice.PublicExamples1;

public class PublicExample5 {

	public static void main(String[] args) {
		
		
		PublicExamples1 obj=new PublicExamples1();
		obj.display();

	}

}
